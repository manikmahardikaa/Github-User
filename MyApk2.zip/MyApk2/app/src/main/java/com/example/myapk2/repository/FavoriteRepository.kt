package com.example.myapk2.repository

import android.app.Application
import androidx.lifecycle.LiveData
import com.example.myapk2.database.Favorite
import com.example.myapk2.database.FavoriteDao
import com.example.myapk2.database.FavoriteRoomDatabase
import com.example.myapk2.helper.AppExecutors


class FavoriteRepository(application: Application) {
    private val mFavoriteDao: FavoriteDao
    private val appExecutors: AppExecutors

    init {
        val db = FavoriteRoomDatabase.getDatabase(application)
        mFavoriteDao = db.favoriteDao()
        appExecutors = AppExecutors()
    }

    fun insertFavorite(favorite: Favorite) {
        mFavoriteDao.insertFavorite(favorite)
    }

    fun deleteFavorite(favorite: Favorite) {
        mFavoriteDao.deleteFavorite(favorite)
    }

    fun getFavoriteByUsername(username: String): LiveData<Favorite> {
        return mFavoriteDao.getFavoriteUserByUsername(username)
    }
}
