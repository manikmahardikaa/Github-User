package com.example.myapk2.ui.main

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.myapk2.R
import com.example.myapk2.database.Favorite
import com.example.myapk2.databinding.ActivityDetailBinding
import com.example.myapk2.helper.ViewModelFactory
import com.google.android.material.tabs.TabLayoutMediator

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding
    private lateinit var mainViewModel: MainViewModel
    private lateinit var adapter: SectionsPagerAdapter
    private lateinit var detailViewModel: DetailViewModel
    private var isFavorite: Boolean = false // Inisialisasi dengan false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mainViewModel = ViewModelProvider(this).get(MainViewModel::class.java)
        detailViewModel = ViewModelProvider(this, ViewModelFactory(application)).get(DetailViewModel::class.java)

        val username = intent.getStringExtra(EXTRA_USERNAME)
        val avatarUrl = intent.getStringExtra(EXTRA_AVATAR_URL)

        if (username != null) {
            mainViewModel.fetchUserDetails(username)
        }

        binding.loadingProgressBar.visibility = View.VISIBLE

        mainViewModel.detailUser.observe(this) { detailUser ->
            if (detailUser != null) {
                binding.usernameTextView.text = detailUser.login
                binding.followerCountTextView.text = detailUser.followers.toString()
                binding.followingCountTextView.text = detailUser.following.toString()

                Glide.with(this)
                    .load(avatarUrl) // Menggunakan avatarUrl yang diterima dari Intent
                    .into(binding.contactImageView)

                binding.loadingProgressBar.visibility = View.GONE

                if (username != null) {
                    adapter = SectionsPagerAdapter(this, username)
                    setupViewPager()

                    detailViewModel.isFavorite.observe(this, Observer { favoriteUser ->
                        // Ketika data berubah, perbarui ikon favorite sesuai kondisi
                        isFavorite = favoriteUser ?: false // Gunakan elvis operator untuk mengatasi nullable
                        updateFavoriteIcon(isFavorite)
                    })

                    detailViewModel.checkIsFavorite(username).observe(this){ favorite ->
                        detailViewModel.insertFavorite(favorite)
                    }
                }
            }
        }

//        binding.fabAdd.setOnClickListener {
//            detailViewModel.insertFavorite(favor)
//        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun updateFavoriteIcon(isFavorite: Boolean) {
        val favoriteIcon = if (isFavorite) R.drawable.ic_favorite else R.drawable.ic_unfavorit
        binding.fabAdd.setImageResource(favoriteIcon)
    }




    private fun setupViewPager() {
        val viewPager: ViewPager2 = binding.viewPager
        val tabLayout = binding.tabLayout

        viewPager.adapter = adapter

        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = when (position) {
                0 -> "Following"
                else -> "Followers"
            }
        }.attach()
    }

    companion object {
        const val EXTRA_USERNAME = "extra_username"
        const val EXTRA_AVATAR_URL = "extra_avatar_url"
    }
}
