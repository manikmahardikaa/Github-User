package com.example.myapk2.ui.main

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapk2.databinding.ActivityFavoriteBinding

class FavoriteActivity : AppCompatActivity() {
    private lateinit var binding: ActivityFavoriteBinding
//    private val favoriteViewModel: FavoriteViewModel
    private val favoriteAdapter: FavoriteAdapter by lazy {
        FavoriteAdapter()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavoriteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = favoriteAdapter

//        val username = intent.getStringExtra(DetailActivity.EXTRA_USERNAME) ?: ""
//        favoriteViewModel.getFavoriteByUsername(username).observe(this) { favoriteUsers ->
//
//            favoriteAdapter.setListFavorite(favoriteUsers)
//        }
    }
}

